import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import './bodyNode.scss';

export default memo(({ data, isConnectable }) => {
  return (
    <div className='parentNode'>
    </div>
  );
});