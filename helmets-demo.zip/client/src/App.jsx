import React from 'react';
import MainContainer from './components/main-container/main-container.jsx';

import './App.scss';

export default function App() {
  return (
    <div className="app">
      <MainContainer />
    </div>
  );
}
