const values = {
  fullnameOverride: "overriden-backend-name",
  replicaCount: 6
}

module.exports = values;